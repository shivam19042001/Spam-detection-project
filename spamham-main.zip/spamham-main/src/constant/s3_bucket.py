TRAINING_BUCKET_NAME = "spamham-detector-model1"
PREDICTION_BUCKET_NAME = "spamham-detector-model1"

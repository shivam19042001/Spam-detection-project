DATABASE_NAME = "pws_projects"
COLLECTION_NAME = "spam_ham"
